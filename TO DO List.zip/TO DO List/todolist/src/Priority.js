import React from "react";

export default function Priority() {
  return <div>Priority</div>;
}
